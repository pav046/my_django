from women.utils import menu


def get_mainmenu(request):
    return {'mainmenu': menu}
